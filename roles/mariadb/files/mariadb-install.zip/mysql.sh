#!/bin/bash
export MYSQL_HOME=/usr/local/mariadb
export PATH=$MYSQL_HOME/bin:$PATH
