#!/bin/bash
datadir="/data/mariadb"
mariadbconf="my.cnf"
mariadbtar="mariadb-10.4.12-linux-systemd-x86_64.tar.gz"
mariadbc="mariadb-10.4.12-linux-systemd-x86_64"

yum -y install libaio.so.1 libaio-devel
groupadd mysql
useradd -g mysql mysql
mkdir -p $datadir && mkdir $datadir/{log,log-bin,data}

tar zxf $mariadbtar && mv $mariadbc mariadb
mv mariadb /usr/local/
cp $mariadbconf /etc && cp mysql.sh /etc/profile.d/
cd /data && chmod 766 mariadb && chown -R mysql.mysql mariadb
cd /root

/usr/local/mariadb/scripts/mysql_install_db --user=mysql

cp mariadb.service /usr/lib/systemd/system
# systemctl enable mariadb
# mysqladmin -uroot -p password 6spEvePSWP5DpUzh
#改认证模式
# update mysql.user set plugin = 'mysql_native_password' where user = 'root';
# 然后再
# set password = password('123456')

systemctl daemon-load
bash && source /etc/profile
