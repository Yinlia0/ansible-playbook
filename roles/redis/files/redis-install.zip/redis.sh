#!/bin/bash

redistar="redis-4.0.14.tar.gz"
redisdir="redis-4.0.14"
redisinstall="/usr/local/redis"
redisconf="redis.conf"


mkdir /usr/local/redis && mkdir -p /data/redis
tar zxf $redistar && cd $redisdir
make PREFIX=/usr/local/redis install
mkdir $redisinstall/{conf,log}
cp ../$redisconf $redisinstall/conf
#ln -s /usr/local/redis/bin/redis-cli /usr/bin/redis-cli && ln -s /usr/local/redis/bin/redis-server /usr/bin/redis-server

cat>/etc/systemd/system/redis.service<<-EOF
[Unit]
Description=Redis In-Memory Data Store
After=network.target
 
[Service]
User=root
Group=root
Type=forking
ExecStart=/usr/local/redis/bin/redis-server /usr/local/redis/conf/redis.conf
ExecStop=/usr/local/redis/bin/redis-cli shutdown
Restart=always
 
[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-load
bash
